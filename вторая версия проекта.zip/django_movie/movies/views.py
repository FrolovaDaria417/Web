from django.shortcuts import render, redirect
from django.views.generic.base import View
from django.http import HttpResponse,HttpResponseNotFound,Http404

from .models import Movie
# Create your views here.


class MoviesView(View):
    #Список фильмов
    def get(self,request): 
        movies = Movie.objects.all()
        return render(request, '/movies/movie_list', {'movie_list':movies} )
    
    
def get(request):
    movies = Movie.objects.all()
    return render(request, 'movies/movie_list', {'movie_list':movies} )
    