from django.db import models
from datetime import date

from django.db.models.deletion import SET_NULL

class Category(models.Model):
    #Категории 
    
    name = models.CharField('Категория', max_length=150) #первый аргумент - дефолтное значение в случае не указанного
    description = models.TextField('Описание')
    url = models.SlugField(max_length=160,unique=True) #текстовое поле только из букв,цифр, подчеркиваний и дефисов
    
    
    def __str__(self):
        return self.name  #Возвращает строковое представление модели 


#Контейнер - опция из мета-данных, прикрепленных к модели
    class Meta:
        #Имена объектов во мн. и ед. числе 
        verbose_name = 'Категория' 
        verbose_name_plural = 'Категории'
    
    
class Actor(models.Model):
     #Актеры и режисеры
    name = models.CharField('Имя', max_length=100)
    age = models.PositiveSmallIntegerField('возраст', default=0)
    description = models.TextField('Описание', default='')
    image = models.ImageField('Изображение', upload_to = 'actors/') 
     
    def __str__(self):
         return self.name
     
    class Meta:
        verbose_name = 'Актеры и режисеры' 
        verbose_name_plural = 'Актеры и режисеры'
    
    
class Genre(models.Model):
    #Жанры
    name = models.CharField('Жанр', max_length=100)
    description = models.TextField('Описание')
    url = models.SlugField(max_length=160,unique=True)
    
    
    class Meta:
        verbose_name = 'Жанр' 
        verbose_name_plural = 'Жанры'
        
    
class Movie(models.Model):
    #Фильмы
    title = models.CharField('Название', max_length=100)
    tagle = models.CharField('Слоган', max_length=100, default='')
    description = models.TextField('Описание')
    poster = models.ImageField('Постер', upload_to = 'movies/')
    year = models.PositiveSmallIntegerField('Дата выхода', default=2021) 
    country = models.CharField('Страна', max_length=30)
    
    #Связи: verbose_name - имя для поля, 
    directors = models.ManyToManyField(Actor, verbose_name='Режиссер',related_name='film_director')
    actors = models.ManyToManyField(Actor,verbose_name='Актеры', related_name='film_actors' )
    genres = models.ManyToManyField(Genre, verbose_name='Жанр')
    
    
    world_premiere = models.DateField('Премьера в мире', default=date.today)
    budget = models.PositiveSmallIntegerField('бюджет', default=0, help_text='Указать сумму в долларах')
    fees_in_usa = models.PositiveSmallIntegerField('Сборы в США', default=0,help_text='Указать сумму в долларах' )
    fees_in_world = models.PositiveSmallIntegerField('Сборы в мире', default=0,help_text='Указать сумму в долларах')
    
    #Отношение многие к одному
    category = models.ForeignKey(Category, verbose_name='категория', on_delete=models.SET_NULL, null=True)
    
    url = models.SlugField(max_length=160, unique=True)
    draft = models.BooleanField('Черновик',default=False)
    
    def __str__(self):
        return self.title
    
    class Meta:
        verbose_name = 'Фильм' 
        verbose_name_plural = 'Фильмы'
        
class MovieShots(models.Model):
    #Кадры кино
    title = models.CharField('Заголовок', max_length=100)
    description = models.TextField('Описание')
    image = models.ImageField("Изображение", upload_to='movie_shots/')
    movie = models.ForeignKey(Movie, verbose_name='Фильм', on_delete=models.CASCADE)
    
    
    def __str__(self):
        return self.title
    
    
    class Meta:
        verbose_name = 'Кадр из фильма' 
        verbose_name_plural = 'Кадры из фильма'
        
        
class RatingStar(models.Model):
    #Оценка фильма
    value = models.PositiveSmallIntegerField(default=0)
    
    def __str__(self):
        return self.value
    
    class Meta:
        verbose_name = 'Звезда рейтинга' 
        verbose_name_plural = 'Звезды рейтинга'
        
        
class Rating(models.Model):
    #Рейтинг
    ip = models.CharField('ip адресс', max_length=15)
    star = models.ForeignKey(RatingStar, on_delete=models.CASCADE, verbose_name='звезда')
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE, verbose_name='фильм')
    
    def __str__(self):
        return f"{self.star} - {self.movie}"
    
    class Meta:
        verbose_name = 'Рейтинг' 
        verbose_name_plural = 'Рейтинги'
    
        
    
class Reviews(models.Model):
    #Отзывы
    email = models.EmailField()
    name = models.CharField('Имя', max_length=100)
    text = models.TextField('Сообщение', max_length=500)
    # Запись ссылается на запись в этой же таблице
    parent = models.ForeignKey('self',verbose_name='Родитель',on_delete=SET_NULL, blank=True, null=True) 
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE)
    
    def __str__(self):
        return f"{self.name} - {self.movie}"
    
    
    class Meta:
        verbose_name = 'Отзыв' 
        verbose_name_plural = 'Отзывы'
    
    
    
    