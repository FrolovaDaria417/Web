@extends('layouts.app')

@section('content')



<div class="my-3 p-3 bg-body rounded shadow-sm">
@foreach($user_task->task as $tas)
   <div class="d-flex text-muted pt-3">
     <svg class="bd-placeholder-img flex-shrink-0 me-2 rounded" width="32" height="32" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 32x32" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#007bff"/><text x="50%" y="50%" fill="#007bff" dy=".3em">32x32</text></svg>

     <div class="pb-3 mb-0 small lh-sm border-bottom w-100">
       <div class="d-flex justify-content-between">
         <strong class="text-gray-dark">{{$tas->name}}</strong>
         <a href="{{route('task.show', $tas->id )}}">Detail</a>
       </div>
       <span class="d-block">{{ $tas->date_start }} - {{ $tas->date_end }}<span>
     </div>
   </div>

   <script src="/docs/5.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
   <script src="offcanvas.js"></script>
 </body>
@endforeach

@endsection
