@extends('layouts.app')

@section('content')
    <div class="table-responsive">
        <table class="table table-striped table-sm">
            <thead>
            <tr>
                <th>#</th>
                <th>Title</th>
                <th>Date range</th>
                <th>Executors</th>
                <th>Created at</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            @foreach($tasks as $task)
                <tr>
                    <td>{{ $task->id }}</td>
                    <td>{{ $task->name }}</td>
                    <td>{{ $task->date_start }} - {{ $task->date_end }}</td>
                    <td>
                        @foreach($task->executor as $executor)
                            <a href="{{ route('users.show', ['user'=> $executor->id]) }}" class="badge bg-success">
                                {{ $executor->name }}
                            </a>
                        @endforeach
                    </td>
                    <td>{{ $task->created_at }}</td>
                    <td>
                        <a class="btn btn-sm btn-outline-primary" href="{{ route('task.show', ['task'=> $task->id]) }}">Show</a>
                        <button class="btn btn-sm btn-outline-success" type="button">Done</button>
                        <button class="btn btn-sm btn-outline-danger" type="button">Delete</button>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
@endsection