@extends('layouts.app')

@section('content')

<div style="margin-left:25px">
			<div id="circle"></div>
			<div><span style="font-size: 28px; margin-left: 120px; font-family: Comic Sans MS, Comic Sans;">{{$user->name}}</span></div>
			<div>
				<table class="table table-bordered" style="width:300px">
					<tbody>
    					<tr>
    			  			<td>Телефон: 8-800-555-35-35</td>
    			  		</tr>

    			  		<tr>
    			  			<td>Email: <a href="mailto:{{$user->email}}">{{$user->email}}</a></td>
    			  		</tr>

    			  		<tr>
    			  			<td><button type="button" class="btn btn-outline-success btn-sm" style="width:250px; margin-left:15px;">Contact</button></td>
    			  		</tr>
    			  	</tbody>
    			</table>
			</div>
@endsection
