@extends('layouts.app')

@section('content')

<table class="table">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">Name</th>
      <th scope="col">email</th>
      <th scope="col">Status</th>
    </tr>
  </thead>
  <tbody>
    @foreach($users as $user)
    <tr>



      <td>{{$user->id}}</td>
      <td><a href="{{ route('users.show', $user -> id) }}"> {{$user->name}} </a></td>
      <td>{{$user->email}}</td>
      <td>T/D</td>
    </tr>
    @endforeach
  </tbody>
</table>



@endsection
