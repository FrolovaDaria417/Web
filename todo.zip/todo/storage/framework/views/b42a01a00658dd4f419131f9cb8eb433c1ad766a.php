<?php $__env->startSection('content'); ?>
<div class="table-responsive">
    <table class="table table-striped table-sm">
        <thead>
        <tr>
            <th>id</th>
            <th>Name</th>
            <th>Description</th>
            <th>Datetime</th>
            <th>Author</th>
            <th></th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($task->id); ?></td>
                <td><?php echo e($task->description); ?></td>
                <td><?php echo e($task->name); ?></td>
                <td><?php echo e($task->date_start); ?> - <?php echo e($task->date_end); ?></td>
                <td>
                    <?php $__currentLoopData = $task->executor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $executor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('users.show', ['user'=> $executor->id])); ?>" class="badge bg-success">
                            <?php echo e($executor->name); ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td><?php echo e($task->created_at); ?></td>
                <td>
                    <a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('task.show', ['task'=> $task->id])); ?>">Show</a>
                    <button class="btn btn-sm btn-outline-success" type="button">Done</button>


                    <button class="btn btn-sm btn-outline-danger" type="button">
                      Delete
                    </button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\todo\resources\views/task/index.blade.php ENDPATH**/ ?>