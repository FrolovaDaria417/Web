

<?php $__env->startSection('content'); ?>

<div style="margin-left:25px">
			<div id="circle"></div>
			<div><span style="font-size: 28px; margin-left: 120px; font-family: Comic Sans MS, Comic Sans;"><?php echo e($user->name); ?></span></div>
			<div>
				<table class="table table-bordered" style="width:300px">
					<tbody>
    					<tr>
    			  			<td>Телефон: 8-800-555-35-35</td>
    			  		</tr>

    			  		<tr>
    			  			<td>Email: <a href="mailto:<?php echo e($user->email); ?>"><?php echo e($user->email); ?></a></td>
    			  		</tr>

    			  		<tr>
    			  			<td><button type="button" class="btn btn-outline-success btn-sm" style="width:250px; margin-left:15px;">Contact</button></td>
    			  		</tr>
    			  	</tbody>
    			</table>
			</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\todo\resources\views/users/show.blade.php ENDPATH**/ ?>