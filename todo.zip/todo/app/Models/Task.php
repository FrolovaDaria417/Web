<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    use HasFactory;

    protected $table = 'tasks';
    protected $fillable = [
        'name',
        'project_id',
        'description',
        'date_start',
        'date_end',
    ];



    public function project()
    {
        return $this->belongsTo(Project::class);
    }

    public function executor()
    {
        return $this->belongsToMany(User::class, 'user_task','task_id','user_id' );
    }
}
