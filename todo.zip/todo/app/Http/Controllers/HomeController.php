<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Task;
use App\Models\User;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $auth_id = Auth()->user()->id;
        $user_sign = User::find($auth_id);
        $user_task = User::with('task')->findOrFail($auth_id);
        //dump($user_task->name);

        return view('home', compact('user_task','user_sign'));
    }
}
